package com.mishra.pocketmech.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.mishra.pocketmech.Adapters.FAQ.FAQAdapter;
import com.mishra.pocketmech.Adapters.FAQ.ItemFAQ;
import com.mishra.pocketmech.Adapters.FilterAdapter;
import com.mishra.pocketmech.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FAQActivity extends AppCompatActivity implements FilterAdapter.BottomSheetListener {

    ImageView top;
    LinearLayout search;
    RecyclerView display;
    EditText searchIn;

    FloatingActionButton filter;

    String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fep_layout);

        filter = findViewById(R.id.filterIcon);
        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FilterAdapter filterNav = new FilterAdapter(type);
                filterNav.show(getSupportFragmentManager(), "example bottom tag");

            }
        });


        top = findViewById(R.id.topImage);
        search = findViewById(R.id.searchLay);
        display = findViewById(R.id.problemRec);
        searchIn = findViewById(R.id.searchIn);

        type = "Bike";

        if (getIntent().hasExtra("type")){
            type = getIntent().getStringExtra("type");
        }

        if(type.equalsIgnoreCase("Car")){
            top.setImageResource(R.drawable.car);
            loadFAQCar(display);
        }else {
            top.setImageResource(R.drawable.rsz_bike);
            loadFAQBike(display);
        }
    }


    private void loadFAQCar(RecyclerView display) {
        RecyclerView.LayoutManager layoutManager;

        final List<ItemFAQ> list = new ArrayList();
        list.clear();
        layoutManager = new GridLayoutManager(this, 3);
        display.setLayoutManager(layoutManager);

        ItemFAQ faq = new ItemFAQ();
        faq.setImage(R.drawable.alarm);
        faq.setName("Alarm");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.bumper);
        faq.setName("Bumper");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.chassis);
        faq.setName("Chassis");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.dashboard);
        faq.setName("Dashboard");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.car_door);
        faq.setName("Door");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.lights);
        faq.setName("Electronics");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.engine);
        faq.setName("Engine");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.fuel);
        faq.setName("Fuel");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.suspension);
        faq.setName("Suspension");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.wheel);
        faq.setName("Tyres");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.lubricant);
        faq.setName("Lubricants");
        list.add(faq);


        faq = new ItemFAQ();
        faq.setImage(R.drawable.spray_paint);
        faq.setName("Paint");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.steering_wheel);
        faq.setName("Steering");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.towing_vehicle);
        faq.setName("Tow");
        list.add(faq);

        FAQAdapter adapter = new FAQAdapter(list, this, "Car");
        display.setLayoutManager(layoutManager);
        display.setAdapter(adapter);
    }

    private void loadFAQBike(RecyclerView display) {

        RecyclerView.LayoutManager layoutManager;

        final List<ItemFAQ> list = new ArrayList();
        layoutManager = new GridLayoutManager(this, 3);
        display.setLayoutManager(layoutManager);

        ItemFAQ faq = new ItemFAQ();
        faq.setImage(R.drawable.chain_bike);
        faq.setName("Chain");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.engine_bike);
        faq.setName("Engine");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.gear_bike);
        faq.setName("Gear");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.headlamp_bike);
        faq.setName("Lights");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.helmet_bike);
        faq.setName("Accessories");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.speedometer_bike_1);
        faq.setName("Speedometer");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.suspension_bike);
        faq.setName("Suspension");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.wheels_bike);
        faq.setName("Wheels");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.spray_paint);
        faq.setName("Paint");
        list.add(faq);

        faq = new ItemFAQ();
        faq.setImage(R.drawable.towing_vehicle);
        faq.setName("Tow");
        list.add(faq);

        FAQAdapter adapter = new FAQAdapter(list, this, "Bike");
        display.setLayoutManager(layoutManager);
        display.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }

    @Override
    public void onItemClicked(String text, int limit) {
    if (text.equals("Car")){
        Intent intent = new Intent(getApplicationContext(), FAQActivity.class);
        intent.putExtra("type", "Car");
        startActivity(intent);
    }
        else if (text.equals("Bike")){
            Intent intent = new Intent(getApplicationContext(), FAQActivity.class);
            intent.putExtra("type", "Bike");
            startActivity(intent);
        }
    }
}