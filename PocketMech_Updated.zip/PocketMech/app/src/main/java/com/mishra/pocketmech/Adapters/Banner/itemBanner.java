package com.mishra.pocketmech.Adapters.Banner;

public class itemBanner {
    String url;


    public itemBanner() {
    }

    public itemBanner(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
