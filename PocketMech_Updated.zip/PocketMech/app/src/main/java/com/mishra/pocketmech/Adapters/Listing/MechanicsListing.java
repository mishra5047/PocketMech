package com.mishra.pocketmech.Adapters.Listing;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.mishra.pocketmech.R;

public class MechanicsListing extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanics_listing);
    }
}