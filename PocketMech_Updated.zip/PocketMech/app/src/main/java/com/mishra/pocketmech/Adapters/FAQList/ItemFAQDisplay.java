package com.mishra.pocketmech.Adapters.FAQList;

public class ItemFAQDisplay {

    String problem, solution;

    public String getProblem() {
        return problem;
    }

    public void setProblem(String problem) {
        this.problem = problem;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }
}
